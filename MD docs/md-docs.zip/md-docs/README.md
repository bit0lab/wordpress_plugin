# MD Docs

WordPress の `uploads/docs/{repo}/` 配下を自動検出し、複数リポジトリの Markdown をドキュメントとして表示するプラグインです。

## 動作要件

- WordPress 6.4 以上
- PHP 8.0 以上
- 「設定 → パーマリンク設定」で「基本」以外のパーマリンク構造を使用

外部ライブラリは使用しません。

## プラグイン構成

| ファイル | 責務 |
| --- | --- |
| `md-docs.php` | 初期化、ルーティング、ファイル探索、Markdown 変換 |
| `class-md-docs-settings.php` | 設定ページ、許可ファイルの保存と検証 |
| `class-md-docs-view.php` | ドキュメント、一覧、通知などの HTML 生成 |
| `assets/md-docs.css` | 表示スタイル |

## インストール

1. `md-docs.zip` を WordPress 管理画面の「プラグイン → 新規プラグインを追加 → プラグインのアップロード」からアップロードします。
2. 「MD Docs」を有効化します。
3. `wp-content/uploads/docs/` を作成し、Markdown と画像を配置します。
4. 既存サイトで URL が 404 になる場合は、「設定 → パーマリンク設定」を開いて、そのまま「変更を保存」を押します。

## フォルダ構成

```text
wp-content/uploads/docs/
├── repo-a/
│   ├── README.md
│   ├── guide/
│   │   └── install.md
│   └── images/
│       └── screen.png
└── repo-b/
    ├── README.md
    └── usage.md
```

リポジトリ名には半角英数字、ピリオド、ハイフン、アンダースコアを使用できます。シンボリックリンクは探索対象外です。

## URL

| URL                           | 内容                      |
| ----------------------------- | ------------------------- |
| `/docs/`                      | リポジトリ一覧            |
| `/docs/repo-a/`               | `repo-a/README.md`        |
| `/docs/repo-a/guide/install/` | `repo-a/guide/install.md` |

各フォルダの `README.md` も、そのフォルダのトップとして表示できます。

## ショートコード

固定ページなどには次のショートコードを配置できます。

```text
[md_docs]
[md_docs repo="repo-a"]
[md_docs repo="repo-a" path="guide/install"]
[md_docs repo="*" path="pr"]
```

`path` にはリポジトリを基準としたパスを指定し、末尾の `.md` は省略できます。`repo` と `path` を指定した場合、本文には指定した Markdown を表示し、サイドバーには同じリポジトリ内の Markdown 一覧を表示します。

`repo="*"` を指定すると、許可済みの全リポジトリから `path` に一致する Markdown を探し、1ページ内にリポジトリ別のセクションとしてまとめて表示します。該当ファイルが存在しない、または設定画面で許可されていないリポジトリは表示されません。ワイルドカードを使う場合、`path` の指定は必須です。

## 表示ファイルの設定

WordPress 管理画面の「設定 → MD Docs」で、公開を許可する Markdown ファイルをリポジトリごとに選択できます。

初回保存までは検出されたすべての Markdown ファイルが表示対象です。設定を保存すると、チェックしたファイルだけがサイドバーと本文に表示され、未選択のファイルは直接 URL を指定しても表示されません。ファイルを追加した場合は設定ページを開き、表示を許可してから保存してください。

## 表示テーマ

MD Docs の画面は、端末やブラウザのカラーモードにかかわらずライトテーマで表示されます。画面幅が 760px 以下の場合は、サイドバーと本文を縦に並べて表示します。

## Markdown 内の相対パス

Markdown ファイルからの相対リンクと相対画像を、同じリポジトリ内で解決します。

```markdown
[インストール](guide/install.md)
[上の階層](../README.md)
![画面](../images/screen.png)
```

`.md` へのリンクは `/docs/{repo}/{path}/` に変換されます。画像やその他のファイルは `uploads/docs/{repo}/` の公開 URL に変換されます。`http`、`https`、`mailto`、`tel`、ページ内アンカーはそのまま使用できます。

## GitHub Actions で同期する場合

同期先をリポジトリごとに分けてください。

```text
wp-content/uploads/docs/repo-a/
wp-content/uploads/docs/repo-b/
```

デプロイ方法はサーバーに合わせて rsync、SFTP、SSH などを利用します。認証情報は GitHub Actions の Secrets に保存し、リポジトリや Workflow に直接書かないでください。

リポジトリ一覧と変換済みの Markdown 本文は、WordPress の Transient に5分間キャッシュされます。各リポジトリ内の Markdown ファイル一覧は表示時に走査されるため、追加・削除は次回表示時に反映されます。本文キャッシュのキーには更新日時とファイルサイズが含まれるため、通常の内容更新は次回表示時に反映されます。

## セキュリティ上の仕様

- `realpath` とベースディレクトリ検証によるディレクトリトラバーサル対策
- リポジトリ名の許可リスト検証
- WordPress の `wp_kses` による生成 HTML のサニタイズ
- 未知の URL スキームを無効化
- シンボリックリンクを探索対象から除外

Markdown に記述した生の HTML は表示されません。このプラグインの Markdown 対応は、見出し、段落、強調、リンク、画像、リスト、引用、水平線、インラインコード、コードブロックを対象とした軽量実装です。

## アンインストール

プラグインを停止して削除してください。`uploads/docs/` 内のファイルは削除されません。必要であれば別途バックアップ後に削除してください。
